<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GUMAS CARGO #1Best Cargo services provider in Kenya</title>
    <link rel=icon href="assets/img/favicon.ico" sizes="20x20" type="image/png">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/css/vendor.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

</head>
<body>
   <header class="navbar-area">
        <div class="navbar-top">

            <div class="container p-lg-0">
                <div class="row">
                    <div class="col-lg-10 col-md-9 text-md-start text-center">
                     
                        <ul class="topbar-left">


                            <li><svg width="12" height="17" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6 0C7.0625 0 8.0625 0.28125 9 0.8125C9.90625 1.375 10.625 2.09375 11.1875 3C11.7188 3.9375 12 4.9375 12 6C12 6.625 11.9062 7.15625 11.7812 7.625C11.625 8.125 11.3438 8.71875 10.9375 9.4375C10.625 9.9375 10.0312 10.9375 9.125 12.375L7.28125 15.2812C7.09375 15.5938 6.8125 15.8125 6.5 15.9375C6.15625 16.0625 5.8125 16.0625 5.5 15.9375C5.15625 15.8125 4.90625 15.5938 4.71875 15.2812L2.875 12.375C1.9375 10.9375 1.34375 9.96875 1.0625 9.46875C0.625 8.71875 0.34375 8.125 0.21875 7.625C0.0625 7.15625 0 6.625 0 6C0 4.9375 0.25 3.9375 0.8125 3C1.34375 2.09375 2.0625 1.375 3 0.8125C3.90625 0.28125 4.90625 0 6 0ZM6 14.5L7.96875 11.375C8.78125 10.0625 9.34375 9.15625 9.625 8.71875C9.96875 8.09375 10.1875 7.625 10.3125 7.25C10.4375 6.90625 10.5 6.5 10.5 6C10.5 5.1875 10.2812 4.4375 9.875 3.75C9.46875 3.0625 8.9375 2.53125 8.25 2.125C7.5625 1.71875 6.8125 1.5 6 1.5C5.1875 1.5 4.4375 1.71875 3.75 2.125C3.0625 2.53125 2.5 3.0625 2.09375 3.75C1.6875 4.4375 1.5 5.1875 1.5 6C1.5 6.5 1.53125 6.90625 1.65625 7.28125C1.78125 7.65625 2.03125 8.125 2.40625 8.75C2.65625 9.1875 3.1875 10.0938 4.03125 11.4062C4.8125 12.6562 5.46875 13.6875 6 14.5ZM3.5 6C3.5 6.6875 3.71875 7.28125 4.21875 7.78125C4.71875 8.28125 5.3125 8.5 6 8.5C6.6875 8.5 7.25 8.28125 7.75 7.78125C8.25 7.28125 8.5 6.6875 8.5 6C8.5 5.3125 8.25 4.75 7.75 4.25C7.25 3.75 6.6875 3.5 6 3.5C5.3125 3.5 4.71875 3.75 4.21875 4.25C3.71875 4.75 3.5 5.3125 3.5 6Z" fill="#FA4318"/>
                                </svg>
                                 Shopping Center, Captain Mungai Street, Eastleigh Nairobi</li>
                            
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-3">
                        <ul class="topbar-right social-area text-md-end text-center">
                            <li>
                                <a href="https://www.facebook.com/people/GUMAS-CARGO/100063699963817/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                            </li>

                            <li>
                                <a href="https://www.instagram.com/gumascargo/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-area-1 navbar-area navbar-expand-lg">
            <div class="container nav-container">
                <div class="responsive-mobile-menu">
                    <button class="menu toggle-btn d-block d-lg-none" data-target="#transpro_main_menu" 
                    aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-left"></span>
                        <span class="icon-right"></span>
                    </button>
                </div>
                <div class="logo">
                    <a href="index.php"><img src="assets/img/2.png" alt="img"></a>
                </div>
                <div class="nav-left-part">
                      
                </div>
                <div class="nav-right-part nav-right-part-mobile">
                 
                   <a class="btn btn-base" href="cost-estimator.php"> <span>
                      </span> Cost Estimator
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="transpro_main_menu">
                    <ul class="navbar-nav menu-open">
                        
                        <li class="current-menu-item">
                            <a href="index.php">Home</a>
                        </li>
                        <li><a href="about.php">About Us</a></li>
                        <li >
                            <a href="service.php">Services</a>
                    
                        </li>

                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="branches.php">Our Branches</a></li>
                               
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="nav-right-part nav-right-part-desktop">
                    
                    <a class="btn btn-base" href="cost-estimator.php"><span>
                      </span> Cost Estimator
                    </a>
                </div>
            </div>
        </nav>
    </header>
    <!-- navbar end -->
    
        
    <!-- breadcrumb start -->
    <div class="breadcrumb-area bg-overlay-2" style="background-image:url('assets/img/banner/4.png')">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-inner">
                        <div class="section-title mb-0">
                            <h2 class="page-title">CONTACT US</h2>
                            <ul class="page-list">
                                <li><a href="index.php">Home</a></li>
                                <li>Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end -->  

    <!-- contact area start -->
    <div class="container">
        <div class="contact-area mg-top-120 mb-120">
            <div class="row g-0 justify-content-center">
                <div class="col-lg-7">
                    <form class="contact-form text-center"  action="https://formsubmit.co/8c30853e3efe2aecd09bf1e6804927e7 " method="POST">
                        <h3>GET A QUOTE</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fa fa-user"></i></label>
                                    <input type="text" placeholder="First name" name="First-Name" id="fname">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fa fa-user"></i></label>
                                    <input type="text" placeholder="Second name" name="Second-Name" id="lname">
                                </div>
                            </div>                            
                            
                            
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fa fa-envelope"></i></label>
                                    <input type="email" placeholder="Your email" name="Email" id="email">
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fas fa-calculator"></i></label>
                                    <input type="text" placeholder=" Phone number" name="Phone" id="phone">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fas fa-calculator"></i></label>
                                    <input type="text" placeholder="Origin" name="Origin" id="origin">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="single-input-inner">
                                    <label><i class="fas fa-calculator"></i></label>
                                    <input type="text" placeholder="Destination" name="Destination" id="destination">
                                </div>
                            </div>
                            
                            <!--<div class="col-md-6">
                                <div class="single-select-inner">
                                    <label><i class="far fa-file-alt"></i></label>
                                    <select class="single-select" name="Subject" id="subject">
                                        <option>Subject</option>
                                        <option value="1">Quotation</option>
                                        <option value="2">Other</option>
                                    </select>
                                </div>
                            </div>-->
                            <div class="col-12">
                                <div class="single-input-inner">
                                    <label><i class="fas fa-pencil-alt"></i></label>
                                    <textarea placeholder="Write massage" name="Message" id="message"></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-base" type="submit"> REQUEST QUOTE
                                </button>
                            </div>
                            <!--<input type="hidden" name="_subject" value="QUOTE REQUEST">-->
                            <input type="hidden" name="_captcha" value="false">
                            <input type="hidden" name="_next" value="https://www.gumascargo.com/success.html">
                        </div>
                    </form>
                </div>
                <div class="col-lg-5">
                    <div class="contact-information-wrap">
                        <h3>Head Office Address</h3>
                        <div class="single-contact-info-wrap">
                            <h6>Contact Number:</h6>
                            <div class="media">
                                <div class="icon">
                                    <i class="fa fa-phone-alt"></i>
                                </div>
                                <div class="media-body">
                                    <p>+254 722 854 323</p>
                                    <p>+254 700 001 201</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-contact-info-wrap">
                            <h6>Mail Address:</h6>
                            <div class="media">
                                <div class="icon" style="background: #080C24;">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="media-body">
                                    <p>support@gumascargo.com</p>
                                    <p>cargogumas@gmail.com</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-contact-info-wrap mb-0">
                            <h6>Office Location:</h6>
                            <div class="media">
                                <div class="icon" style="background: #565969;">
                                    <i class="fa fa-map-marker-alt"></i>
                                </div>
                                <div class="media-body">
                                    <p>Shopping Center, Captain Mungai Street</p>
                                    <p>Eastleigh Nairobi, Kenya</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- contact area end -->
<!--
    <div class="contact-g-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d29208.601361499546!2d90.3598076!3d23.7803374!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1589109092857!5m2!1sen!2sbd"></iframe>
    </div>-->

       <!-- footer area start -->
    <footer class="footer-area">
        <div class="footer-top" style="background-image: url(assets/img/footer/bg.png);">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top">
                            <div class="icon">
                                <img src="assets/img/icon/map-marker.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>OFFICE ADDRESS:</h6>
                                <p>Shopping Center, Captain Mungai Street Eastleigh</p>
                                <p>Nairobi, Kenya</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top">
                            <div class="icon">
                                <img src="assets/img/icon/phone.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>CONTACT US:</h6>
                                <p>support@gumascargo.com</p>
                                <p>+254 700 001 201</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top after-none">
                            <div class="icon">
                                <img src="assets/img/icon/clock.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>WORKING HOURS:</h6>
                                <p>Weekdays - Mon-Fri</p>
                                <p>Weekend - Sat & Sun:</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="widget widget_about">
                        <div class="thumb">
                            <img src="assets/img/logo3.jpeg" alt="img">
                        </div>
                        <div class="details">
                            <p>For your best cargo services</p>
                            <ul class="social-media style-border">
                                <li><a href="https://www.facebook.com/people/GUMAS-CARGO/100063699963817/"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/gumascargo/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">USEFULL LINKS</h4>
                        <ul>
                            <li><a href="about.php"><i class="fa fa-arrow-right"></i> About Us</a></li>
                            <li><a href="service.php"><i class="fa fa-arrow-right"></i> Services</a></li>
                            <li><a href="faq.php"><i class="fa fa-arrow-right"></i>FAQ</a></li>
                            <li><a href="contact.php"><i class="fa fa-arrow-right"></i> Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">OUR SERVICES</h4>
                        <ul>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Air Freight</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Ocean Freight</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Online Shopping</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Warehousing</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Distribution</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">Our Branches</h4>
                         <ul>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Nairobi,Kenya</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Dubai, UAE</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Istanbul, TURKEY</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> China</a></li>
                            
                        </ul><br>
                        
                    <a class="btn btn-base" href="cost-estimator.php"> <span>
                      </span> Cost Estimator
                    </a>
                    </div>
                </div>

            </div>         
        </div>
    </footer>
    <!-- footer area end -->

    <!-- footer-bottom area start -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 text-lg-start text-center">
                    <div class="copyright-area">
                        <p>© Copyright 2023  By <a href="#">Gumas Cargo</a>, All right reserved.</p>
                    </div>
                </div>
                <div class="col-lg-6 text-lg-end text-center">
                    <ul>
                        <li>
                            Terms & Condition
                        </li>
                        <li>Privacy & Policy</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- footer-bottom area end -->

    <!-- back to top area start -->
    <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div>
    <!-- back to top area end -->


    <!-- all plugins here -->
    <script src="assets/js/vendor.js"></script>
    <!-- main js  -->
    <script src="assets/js/main.js"></script>
    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/64179eb731ebfa0fe7f3837a/1gru4804d';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!--Start Whatsapp chat button -->
<script defer src="https://widget.tochat.be/bundle.js?key=3a362a02-781e-4f86-9a19-94149ff53a6c"></script>

<!--End Whatsapp chat-->
</body>
</html>