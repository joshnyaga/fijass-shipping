<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GUMAS CARGO #1Best Cargo services provider in Kenya</title>
    <link rel=icon href="assets/img/favicon.ico" sizes="20x20" type="image/png">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/css/vendor.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

</head>
<body>
   <header class="navbar-area">
        <div class="navbar-top">

            <div class="container p-lg-0">
                <div class="row">
                    <div class="col-lg-10 col-md-9 text-md-start text-center">
                     
                        <ul class="topbar-left">


                            <li><svg width="12" height="17" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6 0C7.0625 0 8.0625 0.28125 9 0.8125C9.90625 1.375 10.625 2.09375 11.1875 3C11.7188 3.9375 12 4.9375 12 6C12 6.625 11.9062 7.15625 11.7812 7.625C11.625 8.125 11.3438 8.71875 10.9375 9.4375C10.625 9.9375 10.0312 10.9375 9.125 12.375L7.28125 15.2812C7.09375 15.5938 6.8125 15.8125 6.5 15.9375C6.15625 16.0625 5.8125 16.0625 5.5 15.9375C5.15625 15.8125 4.90625 15.5938 4.71875 15.2812L2.875 12.375C1.9375 10.9375 1.34375 9.96875 1.0625 9.46875C0.625 8.71875 0.34375 8.125 0.21875 7.625C0.0625 7.15625 0 6.625 0 6C0 4.9375 0.25 3.9375 0.8125 3C1.34375 2.09375 2.0625 1.375 3 0.8125C3.90625 0.28125 4.90625 0 6 0ZM6 14.5L7.96875 11.375C8.78125 10.0625 9.34375 9.15625 9.625 8.71875C9.96875 8.09375 10.1875 7.625 10.3125 7.25C10.4375 6.90625 10.5 6.5 10.5 6C10.5 5.1875 10.2812 4.4375 9.875 3.75C9.46875 3.0625 8.9375 2.53125 8.25 2.125C7.5625 1.71875 6.8125 1.5 6 1.5C5.1875 1.5 4.4375 1.71875 3.75 2.125C3.0625 2.53125 2.5 3.0625 2.09375 3.75C1.6875 4.4375 1.5 5.1875 1.5 6C1.5 6.5 1.53125 6.90625 1.65625 7.28125C1.78125 7.65625 2.03125 8.125 2.40625 8.75C2.65625 9.1875 3.1875 10.0938 4.03125 11.4062C4.8125 12.6562 5.46875 13.6875 6 14.5ZM3.5 6C3.5 6.6875 3.71875 7.28125 4.21875 7.78125C4.71875 8.28125 5.3125 8.5 6 8.5C6.6875 8.5 7.25 8.28125 7.75 7.78125C8.25 7.28125 8.5 6.6875 8.5 6C8.5 5.3125 8.25 4.75 7.75 4.25C7.25 3.75 6.6875 3.5 6 3.5C5.3125 3.5 4.71875 3.75 4.21875 4.25C3.71875 4.75 3.5 5.3125 3.5 6Z" fill="#FA4318"/>
                                </svg>
                                 Shopping Center, Captain Mungai Street, Eastleigh Nairobi</li>
                            
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-3">
                        <ul class="topbar-right social-area text-md-end text-center">
                            <li>
                                <a href="https://www.facebook.com/people/GUMAS-CARGO/100063699963817/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                            </li>

                            <li>
                                <a href="https://www.instagram.com/gumascargo/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-area-1 navbar-area navbar-expand-lg">
            <div class="container nav-container">
                <div class="responsive-mobile-menu">
                    <button class="menu toggle-btn d-block d-lg-none" data-target="#transpro_main_menu" 
                    aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-left"></span>
                        <span class="icon-right"></span>
                    </button>
                </div>
                <div class="logo">
                    <a href="index.php"><img src="assets/img/2.png" alt="img"></a>
                </div>
                <div class="nav-left-part">
                      
                </div>
                <div class="nav-right-part nav-right-part-mobile">
                 
                   <a class="btn btn-base" href="cost-estimator.php"> <span>
                      </span> Cost Estimator
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="transpro_main_menu">
                    <ul class="navbar-nav menu-open">
                        
                        <li class="current-menu-item">
                            <a href="index.php">Home</a>
                        </li>
                        <li><a href="about.php">About Us</a></li>
                        <li >
                            <a href="service.php">Services</a>
                    
                        </li>

                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="branches.php">Our Branches</a></li>
                               
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="nav-right-part nav-right-part-desktop">
                    
                    <a class="btn btn-base" href="cost-estimator.php"><span>
                      </span> Cost Estimator
                    </a>
                </div>
            </div>
        </nav>
    </header>
    <!-- navbar end -->
    
        
    <!-- breadcrumb start -->
    <div class="breadcrumb-area bg-overlay-2" style="background-image:url('assets/img/banner/1.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-inner">
                        <div class="section-title mb-0">
                            <h2 class="page-title">ABOUT US</h2>
                            <ul class="page-list">
                                <li><a href="index.php">Home</a></li>
                                <li>About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end -->  

    <!-- about area start -->
    <div class="about-area pd-top-120 pd-bottom-240">
        <div class="container">
            <div class="about-area-inner">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-thumb-wrap">
                            <img class="img-1" src="assets/img/about/shape.png" alt="img">
                            <img class="img-2" src="assets/img/about/1.jpg" alt="img">
                            <img class="img-3" src="assets/img/about/2.jpg" alt="img">
                            <div class="exprience-wrap">
                                <img src="assets/img/about/shape-3.png" alt="img">
                                <div class="details">
                                    <h1>6</h1>
                                    <p>YEARS EXPERIENCE</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 align-self-center">
                        <div class="about-inner-wrap">  
                            <div class="section-title mb-0">
                                <h4 class="subtitle">ABOUT US</h4>
                                <h2 class="title">WELCOME WORLD WIDE BEST
                                        TRANSPORT COMPANY</h2>
                                <p class="content left-line">At Gumas cargo, we offer air cargo, sea cargo, land cargo, door to door, online shopping, parcel delivery, warehouse storage,custom clearance and brokerage at competitive rates.we also offer tailor-made solutions for your cargo services. Gumas Cargo prides itself on offering the highest levels of service to its customers. We offer solution-based services with a personal touch. This friendly and professional approach has been the core of our business success. From the initial contact with a customer, our team will strive to offer a level of service that will leave our customers comfortable with the knowledge that their shipments are closely monitored and handled with care all the way up to their final destination. Get in touch with us for a quote.</p>
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="list-inner-wrap mb-lg-0 mb-4">
                                            <li><img src="assets/img/icon/check.png" alt="img"> Air Freight</li>
                                            <li><img src="assets/img/icon/check.png" alt="img"> Sea Freight</li>
                                            <li><img src="assets/img/icon/check.png" alt="img">Online Shopping</li>
                                            <li><img src="assets/img/icon/check.png" alt="img"> Door to Door delivery</li>
                                            <li><img src="assets/img/icon/check.png" alt="img">Imports / Exports</li>
                                            <li><img src="assets/img/icon/check.png" alt="img">Custom Clearance</li>
                                            <li><img src="assets/img/icon/check.png" alt="img">Warehousing</li>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 align-self-center">
                                        <div class="thumb"><img src="assets/img/about/3.jpg" alt="img"></div>
                                    </div>
                                </div>
                                <div class="btn-wrap">
                                   <!-- <a class="btn btn-base" href="about.php">ABOUT MORE</a>-->
                                    <div class="author-wrap">
                                       <!-- <div class="thumb"><img src="assets/img/about/4.png" alt="img"></div>
                                        <div class="details">
                                            <img src="assets/img/about/signature.png" alt="img">
                                            <p>CEO, Of Company</p>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about area end -->

    <!--fact-area start-->
    <div class="fact-area" style="background: #f9f9f9;">
        <div class="container">
            <div class="fact-counter-area" style="background: url(assets/img/fact/bg.png);">
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-md-6">
                        <div class="single-fact-wrap">
                            <h2><span class="counter">2000</span>+</h2>
                            <h5>Air Freight</h5>
                            <p></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-fact-wrap">
                            <h2><span class="counter">100</span>+</h2>
                            <h5>Sea Freight</h5>
                            <p></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-fact-wrap">
                            <h2><span class="counter">7</span>+</h2>
                            <h5>Warehouse</h5>
                            <p></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-fact-wrap after-none">
                            <h2><span class="counter">80</span>+</h2>
                            <h5>Online Shopping</h5>
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--fact-area end-->

    <!--skill-area start-->
    <div class="skill-area pd-top-120 pd-bottom-120" style="background: #f9f9f9;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 order-lg-2">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="thumb">
                                <img class="w-100" src="assets/img/about/1.webp" alt="img">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="thumb img-2">
                                <img class="w-100" src="assets/img/about/3.webp" alt="img">
                            </div>
                        </div>
                    </div>                    
                </div>
                <div class="col-lg-6 order-lg-1">
                    <div class="section-title mt-lg-0 mt-5">
                        <h4 class="subtitle style-2">OUR SKILLS</h4>
                        <h2 class="title">WHY CHOOSE US?</h2>
                        <p>Did you know you can ship any item from China, UAE or Turkey to Kenya with GUMAS CARGO?
Take advantage of our speedy deliveries at the best rates.</p>
                    </div>
                    <div class="skill-progress-area">
                        <div class="single-progressbar">
                            <div class="title" style="width: 85%;">
                                <h6>Cargo Freight
                                </h6>
                                <div class="progress-count-wrap">
                                    <span class="progress-count counting" data-count="85">0</span>
                                    <span class="counting-icons">%</span>
                                </div>
                            </div>
                            <div class="progress-item" id="progress-running">
                                <div class="progress-bg">
                                    <div id="progress" class="progress-rate" data-value="85">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single-progressbar">
                            <div class="title" style="width: 80%;">
                                <h6>Air Freight
                                </h6>
                                <div class="progress-count-wrap">
                                    <span class="progress-count counting" data-count="80">0</span>
                                    <span class="counting-icons">%</span>
                                </div>
                            </div>
                            <div class="progress-item" id="progress-running-1">
                                <div class="progress-bg">
                                    <div id="progress-1" class="progress-rate" data-value="80">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single-progressbar">
                            <div class="title" style="width: 90%;">
                                <h6>Road Freight
                                </h6>
                                <div class="progress-count-wrap">
                                    <span class="progress-count counting" data-count="90">0</span>
                                    <span class="counting-icons">%</span>
                                </div>
                            </div>
                            <div class="progress-item" id="progress-running-2">
                                <div class="progress-bg">
                                    <div id="progress-2" class="progress-rate" data-value="90">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single-progressbar">
                            <div class="title" style="width: 75%;">
                                <h6>Warehousing
                                </h6>
                                <div class="progress-count-wrap">
                                    <span class="progress-count counting" data-count="75">0</span>
                                    <span class="counting-icons">%</span>
                                </div>
                            </div>
                            <div class="progress-item mb-0" id="progress-running-3">
                                <div class="progress-bg">
                                    <div id="progress-3" class="progress-rate" data-value="75">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--skill-area end-->

    <!--video-area start-->
    <div class="video-area pd-top-120 pd-bottom-120" style="background: #080C24;">
        <div class="video-thumb-wrap">
            <img src="assets/img/video/1.jpg" alt="img" style="opacity:0.4;">
            <a class="video-play-btn" href="#" data-effect="mfp-zoom-in"><i class="fa fa-play"></i></a>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="cta-inner-wrap" style="background: url(assets/img/video/bg.png);">
                        <div class="section-title style-white mb-0">
                            <h4 class="subtitle style-2">LET’S TALK</h4>
                            <h2 class="title">YOU NEED ANY HELP?
                                GET FREE CONSULTATION</h2>
                        </div>
                        <div class="single-cta-wrap">
                            <div class="icon">
                                <svg class="svg-inline--fa fa-phone-alt fa-w-16" aria-hidden="true" focusable="false" data-prefix="fa" data-icon="phone-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z"></path></svg><!-- <i class="fa fa-phone-alt"></i> Font Awesome fontawesome.com -->
                            </div>
                            <div class="details">
                                <h6>Have Any Question</h6>
                                <h3>+254799971555</h3>
                            </div>
                        </div>
                        <a class="btn btn-white" href="tel:+254799971555">CONTACT US</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--video-area end-->

    <!--partner-area start-->
   <!-- <div class="partner-area pd-top-90 pd-bottom-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="section-title text-center">
                        <h4 class="subtitle">HAPPY CLIENTS</h4>
                        <h2 class="title">TRUSTED BY OUR
                            365,000 CLIENTS</h2>
                        <p class="content">Dramatically enhance interactive metrics for reliable services. Proactively unleash fully researched e-commerce.</p>
                    </div>
                </div>
            </div>
            <div class="partner-slider owl-carousel">
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/1.png" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/2.png" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/3.png" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/4.png" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/5.png" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="thumb">
                        <img src="assets/img/partner/6.png" alt="img">
                    </div>
                </div>
            </div> 
        </div>
    </div>-->
    <!--partner-area end-->

       <!-- footer area start -->
    <footer class="footer-area">
        <div class="footer-top" style="background-image: url(assets/img/footer/bg.png);">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top">
                            <div class="icon">
                                <img src="assets/img/icon/map-marker.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>OFFICE ADDRESS:</h6>
                                <p>Shopping Center, Captain Mungai Street Eastleigh</p>
                                <p>Nairobi, Kenya</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top">
                            <div class="icon">
                                <img src="assets/img/icon/phone.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>CONTACT US:</h6>
                                <p>support@gumascargo.com</p>
                                <p>+254 700 001 201</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-footer-top after-none">
                            <div class="icon">
                                <img src="assets/img/icon/clock.png" alt="img">
                            </div>
                            <div class="details">
                                <h6>WORKING HOURS:</h6>
                                <p>Weekdays - Mon-Fri</p>
                                <p>Weekend - Sat & Sun:</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="widget widget_about">
                        <div class="thumb">
                            <img src="assets/img/logo3.jpeg" alt="img">
                        </div>
                        <div class="details">
                            <p>For your best cargo services</p>
                            <ul class="social-media style-border">
                                <li><a href="https://www.facebook.com/people/GUMAS-CARGO/100063699963817/"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/gumascargo/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">USEFULL LINKS</h4>
                        <ul>
                            <li><a href="about.php"><i class="fa fa-arrow-right"></i> About Us</a></li>
                            <li><a href="service.php"><i class="fa fa-arrow-right"></i> Services</a></li>
                            <li><a href="faq.php"><i class="fa fa-arrow-right"></i>FAQ</a></li>
                            <li><a href="contact.php"><i class="fa fa-arrow-right"></i> Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">OUR SERVICES</h4>
                        <ul>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Air Freight</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Ocean Freight</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Online Shopping</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Warehousing</a></li>
                            <li><a href="#"><i class="fa fa-arrow-right"></i> Distribution</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">Our Branches</h4>
                         <ul>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Nairobi,Kenya</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Dubai, UAE</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> Istanbul, TURKEY</a></li>
                            <li><a href="branches.php"><i class="fa fa-arrow-right"></i> China</a></li>
                            
                        </ul><br>
                        
                    <a class="btn btn-base" href="cost-estimator.php"> <span>
                      </span> Cost Estimator
                    </a>
                    </div>
                </div>

            </div>         
        </div>
    </footer>
    <!-- footer area end -->

    <!-- footer-bottom area start -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 text-lg-start text-center">
                    <div class="copyright-area">
                        <p>© Copyright 2023  By <a href="#">Gumas Cargo</a>, All right reserved.</p>
                    </div>
                </div>
                <div class="col-lg-6 text-lg-end text-center">
                    <ul>
                        <li>
                            Terms & Condition
                        </li>
                        <li>Privacy & Policy</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- footer-bottom area end -->

    <!-- back to top area start -->
    <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div>
    <!-- back to top area end -->


    <!-- all plugins here -->
    <script src="assets/js/vendor.js"></script>
    <!-- main js  -->
    <script src="assets/js/main.js"></script>
    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/64179eb731ebfa0fe7f3837a/1gru4804d';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!--Start Whatsapp chat button -->
<script defer src="https://widget.tochat.be/bundle.js?key=3a362a02-781e-4f86-9a19-94149ff53a6c"></script>

<!--End Whatsapp chat-->
</body>
</html>